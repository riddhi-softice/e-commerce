-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2025 at 06:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `watch-e-commerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `address_type` varchar(255) DEFAULT NULL COMMENT 'home, billing, shipping, ofc ..etc',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'size diameter', NULL, NULL),
(2, 'strap material', NULL, NULL),
(3, 'Color', '2025-06-06 11:04:37', '2025-06-06 11:04:37'),
(4, 'Size', '2025-06-06 11:04:37', '2025-06-06 11:04:37');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

CREATE TABLE `attribute_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT 0,
  `value` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`id`, `attribute_id`, `product_id`, `value`, `created_at`, `updated_at`) VALUES
(5, 3, 3, 'Red', '2025-06-06 11:04:59', '2025-06-06 11:04:59'),
(6, 3, 3, 'Blue', '2025-06-06 11:04:59', '2025-06-06 11:04:59'),
(7, 4, 3, 'M', '2025-06-06 11:04:59', '2025-06-06 11:04:59'),
(8, 4, 3, 'L', '2025-06-06 11:04:59', '2025-06-06 11:04:59');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `logo`, `created_at`, `updated_at`) VALUES
(1, 'Rolex', '1.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(2, 'Casio', '2.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(3, 'Fossil', '3.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(4, 'Omega', '4.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(5, 'Timex', '5.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(6, 'Omega', '4.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(7, 'Timex', '5.png', '2025-06-07 00:43:43', '2025-06-07 00:43:43');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`id`, `user_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(2, 1, 4, 2, NULL, NULL),
(3, 1, 1, 2, NULL, '2025-06-10 01:08:08'),
(4, 2, 3, 1, NULL, NULL),
(5, 9, 6, 1, '2025-06-10 04:40:44', '2025-06-10 04:40:44'),
(6, 7, 5, 1, '2025-06-10 22:49:00', '2025-06-10 22:49:00');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Luxury', 'luxury', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(2, 'Sports', 'sports', '2025-06-07 00:43:43', '2025-06-07 00:43:43'),
(3, 'Smartwatches', 'smartwatches', '2025-06-07 00:43:43', '2025-06-07 00:43:43');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_logs`
--

CREATE TABLE `inventory_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `change_type` enum('in','out','return') NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2025_06_07_042210_create_watch_store_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(255) NOT NULL,
  `placed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `warranty_years` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `long_desc` text DEFAULT NULL,
  `additional_info` text DEFAULT NULL,
  `shipping_info` text DEFAULT NULL,
  `return_policy` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `name`, `slug`, `description`, `price`, `sale_price`, `stock`, `warranty_years`, `created_at`, `updated_at`, `long_desc`, `additional_info`, `shipping_info`, `return_policy`) VALUES
(1, 5, 2, 'Timex first', 'timex-new', 'Durable outdoor watch with Indiglo backlight.', 4500.00, 3999.00, 60, 1, '2025-06-07 00:43:44', '2025-06-07 00:43:44', NULL, NULL, NULL, NULL),
(2, 1, 1, 'Rolex Submariner', 'rolex-submariner', 'Iconic dive watch with unmatched durability and style.', 750000.00, 699000.00, 15, 5, '2025-06-07 00:43:43', '2025-06-07 00:43:43', NULL, NULL, NULL, NULL),
(3, 2, 2, 'Casio G-Shock GA-2100', 'casio-gshock-ga2100', 'Rugged watch with carbon core guard and analog-digital display.', 12000.00, 9999.00, 40, 2, '2025-06-07 00:43:43', '2025-06-07 00:43:43', ' <h3>Product Information</h3><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque    volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna viverra    non,    semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis    fermentum.    Aliquam porttitor mauris sit amet orci. Aenean dignissim pellentesque felis.    Phasellus ultrices nulla quis nibh. Quisque a lectus. Donec consectetuer ligula    vulputate sem tristique cursus. </p><ul>    <li>Nunc nec porttitor turpis. In eu risus enim. In vitae mollis elit. </li>    <li>Vivamus finibus vel mauris ut vehicula.</li>    <li>Nullam a magna porttitor, dictum risus nec, faucibus sapien.</li></ul>\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque    volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna viverra    non,    semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis    fermentum.    Aliquam porttitor mauris sit amet orci. Aenean dignissim pellentesque felis.    Phasellus ultrices nulla quis nibh. Quisque a lectus. Donec consectetuer ligula    vulputate sem tristique cursus. </p>', '<h3>Information</h3><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque    volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna viverra    non,    semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis    fermentum.    Aliquam porttitor mauris sit amet orci. </p>\n<h3>Fabric & care</h3><ul>    <li>Faux suede fabric</li>    <li>Gold tone metal hoop handles.</li>    <li>RI branding</li>    <li>Snake print trim interior </li>    <li>Adjustable cross body strap</li>    <li> Height: 31cm; Width: 32cm; Depth: 12cm; Handle Drop: 61cm</li></ul>', ' <h3>Delivery & returns</h3><p>We deliver to over 100 countries around the world. For full details of the    delivery    options we offer, please view our <a href=\"#\">Delivery information</a><br>    We hope you\'ll love every purchase, but if you ever need to return an item you    can    do so within a month of receipt. For full details of how to make a return,    please    view our <a href=\"#\">Returns information</a></p>', NULL),
(4, 3, 3, 'Fossil Gen 6 Smartwatch', 'fossil-gen-6-smartwatch', 'Smartwatch with Wear OS and SpO2 tracking.', 24999.00, 22999.00, 25, 2, '2025-06-07 00:43:44', '2025-06-07 00:43:44', NULL, NULL, NULL, NULL),
(5, 4, 1, 'Omega Speedmaster Moonwatch', 'omega-speedmaster-moonwatch', 'Legendary chronograph worn on the moon.', 560000.00, NULL, 10, 5, '2025-06-07 00:43:44', '2025-06-07 00:43:44', NULL, NULL, NULL, NULL),
(6, 5, 2, 'Timex Expedition Scout', 'timex-expedition-scout', 'Durable outdoor watch with Indiglo backlight.', 4500.00, 3999.00, 60, 1, '2025-06-07 00:43:44', '2025-06-07 00:43:44', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `path` varchar(255) NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `path`, `is_primary`, `created_at`, `updated_at`) VALUES
(1, 3, 'product-12.jpg', 0, NULL, NULL),
(2, 3, 'product-13.jpg', 0, NULL, NULL),
(3, 2, 'product-10-2.jpg', 0, NULL, NULL),
(4, 2, 'product-10-1.jpg', 0, NULL, NULL),
(5, 4, 'product-11-2.jpg', 0, NULL, NULL),
(6, 4, 'product-11-1.jpg', 0, NULL, NULL),
(7, 5, 'product-12-2.jpg', 0, NULL, NULL),
(8, 1, 'product-12-1.jpg', 0, NULL, NULL),
(9, 5, 'product-12-2.jpg', 0, NULL, NULL),
(10, 6, 'product-12-1.jpg', 0, NULL, NULL),
(11, 3, 'product-11.jpg', 0, NULL, NULL),
(12, 6, 'product-12-1.jpg', 0, NULL, NULL),
(13, 1, 'product-10.jpg', 0, NULL, NULL),
(14, 2, 'product-9.jpg', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `strap_material` varchar(255) DEFAULT NULL,
  `size_diameter` double(8,2) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_variants`
--

INSERT INTO `product_variants` (`id`, `product_id`, `color`, `strap_material`, `size_diameter`, `price`, `stock`, `created_at`, `updated_at`) VALUES
(2, 2, 'Red', 'Resin', 44.00, 9999.00, 10, '2025-06-09 05:21:21', '2025-06-09 05:21:21'),
(3, 3, 'Silver', 'Leather', 42.00, 22999.00, 7, '2025-06-09 05:21:21', '2025-06-09 05:21:21'),
(4, 4, 'White', 'Stainless Steel', 42.50, 560000.00, 4, '2025-06-09 05:21:21', '2025-06-09 05:21:21'),
(5, 5, 'Green', 'Nylon', 43.00, 3999.00, 15, '2025-06-09 05:21:21', '2025-06-09 05:21:21');

-- --------------------------------------------------------

--
-- Table structure for table `related_products`
--

CREATE TABLE `related_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `related_product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `related_products`
--

INSERT INTO `related_products` (`id`, `product_id`, `related_product_id`, `created_at`, `updated_at`) VALUES
(1, 1, 4, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(2, 3, 2, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(3, 2, 5, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(4, 3, 5, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(5, 4, 1, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(6, 5, 2, '2025-06-09 06:38:17', '2025-06-09 06:38:17'),
(7, 3, 1, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(8, 3, 4, '2025-06-09 06:38:16', '2025-06-09 06:38:16'),
(9, 3, 6, '2025-06-09 06:38:16', '2025-06-09 06:38:16');

-- --------------------------------------------------------

--
-- Table structure for table `return_requests`
--

CREATE TABLE `return_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `review_title` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `review_title`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 5, 'Absolutely stunning watch! Worth every penny.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(2, 2, 2, 4, 'Tough and reliable. Great for outdoor use.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(3, 3, 3, 3, 'Good features but battery drains fast.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(4, 4, 4, 5, 'A true classic. Feels premium and classy.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(5, 5, 1, 4, 'Affordable and rugged. Strap quality could be better.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(6, 3, 1, 5, 'Absolutely stunning watch! Worth every penny.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(7, 3, 1, 5, 'Absolutely stunning watch! Worth every penny.', 'Good, perfect', '2025-06-09 06:21:51', '2025-06-09 06:21:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Ravi Patel', 'ravi@example.com', '$2y$10$NLP9S/NfWua0jxKRaM8Dz.85JU9H4TrCO3rgajpUwq9gY/7PjWiL6', '9876543210', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(2, 'Anjali Mehta', 'anjali@example.com', '$2y$10$SEektX83RUqD5F9PIo/8l.SdUMltTngJVCxdBTgZzrJEdB0W7R73S', '9988776655', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(3, 'Amit Sharma', 'amit@example.com', '$2y$10$/kJbJavp3CWD.639rwj0r.Ga86lK1rDLY3w6Yj56vIh/s4h/Qythu', '9123456789', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(4, 'Neha Singh', 'neha@example.com', '$2y$10$r037ROE22tKBDf6msatmiu.AucPMG.Xy20hxKb7Ja3RmEQfFAFrVi', '9090909090', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(5, 'Farhan Khan', 'farhan@example.com', '$2y$10$WPKOoltcVDhPBRS59ftJKORW0F9xqCPmpswNV9T8UzUO6VzZY9ONi', '9012345678', '2025-06-09 06:21:51', '2025-06-09 06:21:51'),
(7, NULL, 'a@a.com', '$2y$10$ZWz/wFkbKQ1TXLDfbQk1sef8LFoT/c6dLftPMq5G788OuXUpp6LIS', NULL, '2025-06-10 02:00:07', '2025-06-10 02:00:07'),
(9, 'ds das', 'new@gmail.com', '$2y$10$zMvQqOAXEc9I3LVqQNPrYeXdkyjGsFRxBSHwoUCHdXjX3HEeQ0l1i', NULL, '2025-06-10 04:20:07', '2025-06-10 06:39:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_user_id_foreign` (`user_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_values_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user` (`user_id`),
  ADD KEY `fk_product` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_logs_product_id_foreign` (`product_id`),
  ADD KEY `inventory_logs_variant_id_foreign` (`variant_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`),
  ADD KEY `order_items_variant_id_foreign` (`variant_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_brand_id_foreign` (`brand_id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_images_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_variants_product_id_foreign` (`product_id`);

--
-- Indexes for table `related_products`
--
ALTER TABLE `related_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `related_products_product_id_foreign` (`product_id`),
  ADD KEY `related_products_related_product_id_foreign` (`related_product_id`);

--
-- Indexes for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `return_requests_order_id_foreign` (`order_id`),
  ADD KEY `return_requests_product_id_foreign` (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_product_id_foreign` (`product_id`),
  ADD KEY `reviews_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `attribute_values`
--
ALTER TABLE `attribute_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `related_products`
--
ALTER TABLE `related_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `return_requests`
--
ALTER TABLE `return_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD CONSTRAINT `attribute_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD CONSTRAINT `inventory_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `inventory_logs_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `order_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `related_products`
--
ALTER TABLE `related_products`
  ADD CONSTRAINT `related_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `related_products_related_product_id_foreign` FOREIGN KEY (`related_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD CONSTRAINT `return_requests_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `return_requests_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
