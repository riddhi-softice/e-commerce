<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Molla - Bootstrap eCommerce Template</title>
    <meta name="keywords" content="HTML5 Template">
    <meta name="description" content="Molla - Bootstrap eCommerce Template">
    <meta name="author" content="p-themes">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/assets/images/icons/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/assets/images/icons/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/assets/images/icons/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('public/assets/images/icons/site.html')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('public/assets/images/icons/safari-pinned-tab.svg')); ?>" color="#666666">
    <link rel="shortcut icon" href="<?php echo e(asset('public/assets/images/icons/favicon.ico')); ?>">
    <meta name="apple-mobile-web-app-title" content="Molla">
    <meta name="application-name" content="Molla">
    <meta name="msapplication-TileColor" content="#cc9966">
    <meta name="msapplication-config" content="<?php echo e(asset('public/assets/images/icons/browserconfig.xml')); ?>">
    <meta name="theme-color" content="#ffffff">
    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/plugins/owl-carousel/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/plugins/magnific-popup/magnific-popup.css')); ?>">
    <!-- Main CSS File -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/plugins/nouislider/nouislider.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div class="page-wrapper">
        <!-- ======= Header ======= -->
        <?php echo $__env->make('web.layouts2._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ======= End Header ======= -->

        <div id="main">
            <?php echo $__env->yieldContent('content'); ?>
            <!-- ======= Header ======= -->
            <?php echo $__env->make('web.layouts2._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ======= End Header ======= -->
        </div>
    </div>

    <!-- ======= Mobile Menu  ======= -->
    <?php echo $__env->make('web.layouts2._mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ======= End Mobile Menu  ======= -->

    <!-- ======= Mobile Menu  ======= -->
    <?php echo $__env->make('web.layouts2.signin-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ======= End Mobile Menu  ======= -->

    <?php echo $__env->yieldContent('javascript'); ?>

    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.hoverIntent.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/superfish.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/bootstrap-input-spinner.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.elevateZoom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/bootstrap-input-spinner.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH E:\xampp-8\htdocs\watch-e-commerce\resources\views/web/layouts2/app.blade.php ENDPATH**/ ?>