<footer id="footer" class="container-lg">
    <div class="row">
        <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
            <p class="copyright mb-0"><a href="#">Templateshub</a></p>
        </div>
        <div class="col-md-6 text-center text-md-right social-icons">
            <label class="mr-3">Social Media</label>
            <a href="#" title="Facebook"><i class="icon-facebook-f"></i></a>
            <a href="#" title="Twitter"><i class="icon-twitter"></i></a>
            <a href="#" title="Instagram"><i class="icon-instagram"></i></a>
            <a href="#" title="Youtube"><i class="icon-youtube"></i></a>
            <a href="#" title="Pinterest"><i class="icon-pinterest"></i></a>
        </div>
    </div>
</footer>